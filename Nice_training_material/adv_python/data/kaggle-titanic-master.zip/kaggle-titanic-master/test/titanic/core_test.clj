(ns titanic.core-test
  (:use clojure.test
        titanic.core))


