.. _pred_package_slope_one:

Slope One
---------

.. autoclass:: surprise.prediction_algorithms.slope_one.SlopeOne
    :show-inheritance:
