# DSG17 qualifier

[Leaderboard](https://inclass.kaggle.com/c/dsg17-online-phase)

## Watermark

Via [rasbt/watermark](https://github.com/rasbt/watermark):

```sh
%watermark -v -m -p numpy,pandas,sklearn,xgboost
```

```
CPython 3.6.0
IPython 6.0.0

numpy 1.12.1
pandas 0.20.1
sklearn 0.18.1
xgboost 0.6

compiler   : GCC 4.2.1 Compatible Apple LLVM 6.0 (clang-600.0.57)
system     : Darwin
release    : 15.6.0
machine    : x86_64
processor  : i386
CPU cores  : 4
interpreter: 64bit
```
