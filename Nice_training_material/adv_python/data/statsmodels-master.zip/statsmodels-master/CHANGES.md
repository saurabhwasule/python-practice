Release Notes
=============

The list of changes for each statsmodels release can be found [here](http://www.statsmodels.org/devel/release/index.html). Full details are available in the [commit logs](https://github.com/statsmodels/statsmodels).
